#include <iostream>
#include "sudoku.hpp"
#include "memory.hpp"

Sudoku::Sudoku()
{
    throw std::logic_error("Function \"Sudoku constructor\" is not implemented!");
}

Sudoku::~Sudoku()
{
    throw std::logic_error("Function \"Sudoku destructor\" is not implemented!");
}

bool Sudoku::solve()
{
    throw std::logic_error("Function \"Sudoku solve\" is not implemented!");
}

void Sudoku::print()
{
    throw std::logic_error("Function \"Sudoku print\" is not implemented!");
}

int Sudoku::max_color() const
{
    throw std::logic_error("Function \"Sudoku max_color\" is not implemented!");
}
